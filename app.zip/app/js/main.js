console.log('main loaded');

var chart = d3.select(".chart");
